#ifndef SUMA_SUMA_COORD_MATCH_INCLUDED
#define SUMA_SUMA_COORD_MATCH_INCLUDED

double SUMA_AlignCoords(float *xyz, int N_xyz, byte *cmask, int method, 
                        SUMA_SurfaceObject *SOr, char *opt);
                        
#endif
