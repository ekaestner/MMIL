.. _glossary:

========
Glossary
========

.. glossary::
   :sorted: 


   ROI
      Region of interest. Here these have been manually delineated
      and converted to a digital format as both volumes and surface
      datasets.

