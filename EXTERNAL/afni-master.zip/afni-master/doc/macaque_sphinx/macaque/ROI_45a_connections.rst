.. _ROI_45a_connections:

############################
VLPFC (area 45a) Connections
############################

VLPFC area 45a connections

.. Images:

******
Images
******

.. figure:: media/45a_connections.jpg
   :align: center
   :figwidth: 120%

**Find more information on area 45a at the following link**

:ref:`Area 45a info <ROI_45a>`
