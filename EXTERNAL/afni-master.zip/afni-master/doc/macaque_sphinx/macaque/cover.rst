.. _cover:

*****
Intro
*****

.. _Macaque Atlas Web-based Information:

This website offers supplemental information on regions described in the Saleem macaque atlas. 

.. _cover-figure:

.. figure:: media/Cover2.jpg
   :figwidth: 70%
   :align: center

