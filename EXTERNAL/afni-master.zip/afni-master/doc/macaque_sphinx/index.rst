.. Macaque atlas webinfo master file, created by Daniel Glen
   should at least
   contain the root `toctree` directive.

==========================================================
Welcome to the Saleem Macaque Atlas Web-based Information!
==========================================================

.. toctree::
   :maxdepth: 3
   :numbered: 4
   :includehidden:

   macaquetoc1
   roistoc1
   connectionstoc1
   glossary

==================
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

