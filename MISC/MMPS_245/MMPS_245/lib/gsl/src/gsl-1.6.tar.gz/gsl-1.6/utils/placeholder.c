void
gsl_utils_placeholder (void);

void
gsl_utils_placeholder (void) 
{
  int i = 0;
  i++ ;
}
